/* login/login.js — মূল কাজ (Social Login, Redirect) */

console.log('[MOI] login.js loaded');

const GUEST_SALT = 'MOI_GUEST_SALT_2025_v1';
const views = { login: $('view-login'), profile: $('view-profile'), guest: $('view-guest') };
const redirectOverlay = $('redirectOverlay');

function showView(name){ Object.keys(views).forEach(k => views[k].classList.toggle('hidden', k !== name)); }
function showRedirect(on){ redirectOverlay.classList.toggle('show', on); }

/* ═══ Redirect to Home ═══ */
function redirectToHomepage(data){
    console.log('[REDIRECT]', data);
    showRedirect(true);
    $('redirectWho').textContent = `স্বাগতম, ${data.name || 'User'}! আপনার Homepage-এ নিয়ে যাওয়া হচ্ছে…`;
    setCurrentUser(data);

    let count = 3;
    $('redirectCounter').textContent = `Redirecting in ${count}…`;
    const tick = setInterval(() => {
        count--;
        if (count > 0) $('redirectCounter').textContent = `Redirecting in ${count}…`;
        else {
            $('redirectCounter').textContent = 'Redirecting now…';
            clearInterval(tick);
            window.location.replace(URLS.home);
        }
    }, 500);
}

/* ═══ Button Ripple ═══ */
document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('pointermove', e => {
        const r = btn.getBoundingClientRect();
        btn.style.setProperty('--mx', (e.clientX - r.left) + 'px');
        btn.style.setProperty('--my', (e.clientY - r.top ) + 'px');
    });
    btn.addEventListener('pointerdown', e => {
        const r = btn.getBoundingClientRect();
        const d = Math.max(r.width, r.height) * 2.2;
        const s = document.createElement('span');
        s.className = 'ripple';
        s.style.width = s.style.height = d + 'px';
        s.style.left = (e.clientX - r.left - d/2) + 'px';
        s.style.top  = (e.clientY - r.top  - d/2) + 'px';
        btn.appendChild(s);
        setTimeout(() => s.remove(), 760);
    });
});

/* ═══ Voice Selection ═══ */
let selectedVoice = '';
document.querySelectorAll('.voice-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.voice-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        selectedVoice = btn.dataset.voice;
    });
});

let pendingUser = null;

function showUidBadge(uid){
    $('uidNum').textContent = uid || '------';
    $('uidBadge').classList.add('show');
}

/* ═══ Google Button → Fake Picker ═══ */
$('googleBtn').addEventListener('click', () => {
    openAccountPicker('google');
});

/* ═══ Facebook Button → Fake Picker ═══ */
$('facebookBtn').addEventListener('click', () => {
    openAccountPicker('facebook');
});

/* ═══ Save Profile → Redirect ═══ */
$('saveProfileBtn').addEventListener('click', async () => {
    if (!pendingUser){ alert('কোনো user নেই, আবার login করুন।'); showView('login'); return; }
    const country = $('countrySelect').value;
    if (!country) return alert('অনুগ্রহ করে আপনার দেশ সিলেক্ট করুন।');
    if (!selectedVoice) return alert('অনুগ্রহ করে ভয়েস প্রেফারেন্স সিলেক্ট করুন।');

    const btn = $('saveProfileBtn');
    const original = btn.innerHTML;
    btn.innerHTML = `<span class="loading"></span><span>Saving...</span>`;
    btn.disabled = true;

    try {
        pendingUser.country = country;
        pendingUser.voice = selectedVoice;
        pendingUser.profileComplete = true;
        pendingUser.profileUpdatedAt = Date.now();
        saveUser(pendingUser.uid, pendingUser);

        if (pendingUser.isGuest){
            const guests = JSON.parse(localStorage.getItem('moi_demo_guests') || '{}');
            if (guests[pendingUser.uid]){
                guests[pendingUser.uid].country = country;
                guests[pendingUser.uid].voice = selectedVoice;
                localStorage.setItem('moi_demo_guests', JSON.stringify(guests));
            }
        }
        showUidBadge(pendingUser.moiId);
        const redirectData = {
            uid: pendingUser.uid, name: pendingUser.name, photo: pendingUser.photo,
            email: pendingUser.email || '', country: country, voice: selectedVoice,
            moiId: pendingUser.moiId, diamonds: pendingUser.diamonds || 1000
        };
        if (pendingUser.isGuest) redirectData.guest = '1';
        redirectToHomepage(redirectData);
    } catch(err){
        console.error(err);
        alert('সেভ করতে সমস্যা: ' + err.message);
        btn.innerHTML = original;
        btn.disabled = false;
    }
});

/* ═══════════════════════════════════════════════
   Fake Google / Facebook Account Picker
   ═══════════════════════════════════════════════ */

/* ডেমো অ্যাকাউন্ট লিস্ট */
const FAKE_GOOGLE = [
    { name:'MOI Demo User',   email:'moi.user.demo@gmail.com',    photo:'https://i.pravatar.cc/100?img=12' },
    { name:'Alex Khan',       email:'alex.khan.demo@gmail.com',   photo:'https://i.pravatar.cc/100?img=33' },
    { name:'Priya Sharma',    email:'priya.sharma.demo@gmail.com',photo:'https://i.pravatar.cc/100?img=45' }
];

const FAKE_FACEBOOK = [
    { name:'MOI Demo User',   email:'moi.user@facebook.com',      photo:'https://i.pravatar.cc/100?img=15' },
    { name:'Rahim Ahmed',     email:'rahim.ahmed@facebook.com',   photo:'https://i.pravatar.cc/100?img=52' },
    { name:'Sara Khan',       email:'sara.khan@facebook.com',     photo:'https://i.pravatar.cc/100?img=28' }
];

let _pickerProvider = null;
let _pickerSelected = null;

/* Picker খোলা */
function openAccountPicker(provider){
    _pickerProvider = provider;
    _pickerSelected = null;

    const overlay = $('accountPicker');
    const brand   = $('pickerBrand');
    const list    = $('pickerList');
    const confirm = $('pickerConfirm');
    const cancel  = $('pickerCancel');
    const sub     = $('pickerSub');

    if (provider === 'google'){
        brand.innerHTML = `<i class="fa-brands fa-google g-logo"></i>`;
        sub.textContent = 'to continue to MOI';
        confirm.classList.remove('fb');
        cancel.classList.remove('fb');
    } else {
        brand.innerHTML = `<i class="fa-brands fa-facebook-f fb-logo"></i>`;
        sub.textContent = 'to continue to MOI';
        confirm.classList.add('fb');
        cancel.classList.add('fb');
    }

    const accounts = provider === 'google' ? FAKE_GOOGLE : FAKE_FACEBOOK;
    list.innerHTML = accounts.map((acc, i) => `
        <div class="picker-item ${provider==='facebook'?'fb':''}" data-idx="${i}">
            <img class="pi-avatar" src="${acc.photo}" onerror="this.src='${GUEST_AVATAR}'">
            <div class="pi-info">
                <div class="pi-name">${acc.name}</div>
                <div class="pi-email">${acc.email}</div>
            </div>
            <i class="fa-solid fa-circle-check pi-check"></i>
        </div>
    `).join('');

    list.querySelectorAll('.picker-item').forEach(el => {
        el.addEventListener('click', () => {
            list.querySelectorAll('.picker-item').forEach(x => x.classList.remove('selected'));
            el.classList.add('selected');
            _pickerSelected = accounts[+el.dataset.idx];
            confirm.disabled = false;
        });
    });

    confirm.disabled = true;
    overlay.classList.add('show');
}

/* Picker বন্ধ */
function closeAccountPicker(){
    $('accountPicker').classList.remove('show');
    _pickerProvider = null;
    _pickerSelected = null;
}

/* Confirm চাপলে */
async function confirmAccountPick(){
    if (!_pickerProvider || !_pickerSelected) return;

    const provider = _pickerProvider;
    const account  = _pickerSelected;
    closeAccountPicker();

    await fakeSocialLoginWithAccount(provider, account);
}

/* Picker events */
$('pickerCancel').addEventListener('click', closeAccountPicker);
$('pickerConfirm').addEventListener('click', confirmAccountPick);
$('accountPicker').addEventListener('click', e => {
    if (e.target.id === 'accountPicker') closeAccountPicker();
});

/* ═══ Fake Social Login (account সহ) ═══ */
async function fakeSocialLoginWithAccount(provider, account){
    console.log('[DEMO LOGIN]', provider, account.email);

    /* ✅ FIX: $() কে plain id দিতে হবে (# ছাড়া) */
    const btn = provider === 'google' ? $('googleBtn') : $('facebookBtn');
    const original = btn ? btn.innerHTML : '';
    if (btn){
        btn.innerHTML = `<span class="loading"></span><span>Signing in…</span>`;
        btn.disabled = true;
    }

    try {
        /* ছোট delay যাতে real feel হয় */
        await new Promise(r => setTimeout(r, 700));

        const emailKey = `moi_demo_${provider}_${account.email}`;
        let uid = ls_get(emailKey, null);
        let profile = uid ? getUser(uid) : null;

        if (!profile){
            uid = generateUid(provider);
            const moiId = generateMoiId();
            profile = {
                uid,
                name: account.name,
                photo: account.photo,
                email: account.email,
                moiId,
                country:'', voice:'', diamonds:1000,
                provider: provider === 'google' ? 'Google' : 'Facebook',
                isDemo: true, createdAt: Date.now()
            };
            saveUser(uid, profile);
            ls_set(emailKey, uid);
        }

        if (profile.country && profile.voice){
            /* পুরনো ইউজার — সরাসরি redirect */
            showUidBadge(profile.moiId);
            redirectToHomepage({
                uid: profile.uid, name: profile.name, photo: profile.photo,
                email: profile.email, country: profile.country, voice: profile.voice,
                moiId: profile.moiId, diamonds: profile.diamonds || 1000
            });
        } else {
            /* নতুন ইউজার — Profile Setup এ পাঠাই */
            pendingUser = profile;
            $('profileName').textContent = profile.name;
            $('profileAvatar').innerHTML = `<img src="${profile.photo}" alt="">`;
            $('countrySelect').value = profile.country || '';
            selectedVoice = profile.voice || '';
            document.querySelectorAll('.voice-btn').forEach(b => {
                b.classList.toggle('active', b.dataset.voice === selectedVoice);
            });
            showView('profile');
        }
    } catch(err){
        console.error('[Social Login Error]', err);
        alert('Login failed: ' + err.message);
    } finally {
        if (btn){
            btn.innerHTML = original;
            btn.disabled = false;
        }
    }
}

/* ═══ Auto-Check Session (বন্ধ — প্রতিবার picker দেখাবে) ═══ */
(function(){
    try {
        const stored = getCurrentUser();
        if (stored && stored.uid){
            console.log('[DEMO LOGIN] session found (skip auto-redirect):', stored.moiId);
        }
    } catch(e){}
    console.log('%c[DEMO LOGIN] ready', 'color:#20e3b2;font-weight:800');
})();