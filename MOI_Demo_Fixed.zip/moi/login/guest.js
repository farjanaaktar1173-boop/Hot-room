/* login/guest.js — Guest সিস্টেম */

console.log('[MOI] guest.js loaded');

/* ═══ Guest নামের অংশ ═══ */
const GUEST_ADJ  = ['Cosmic','Neon','Shadow','Golden','Silver','Mystic','Silent','Wild','Swift','Royal','Lunar','Solar','Crystal','Thunder','Frost','Blaze','Storm','Night','Star','Dream'];
const GUEST_NOUN = ['Falcon','Tiger','Phoenix','Dragon','Wolf','Lion','Panther','Viper','Eagle','Lynx','Hawk','Bear','Raven','Fox','Koala','Panda','Leopard','Owl','Orca','Cobra'];

function randomGuestName(){
    const a = GUEST_ADJ[Math.floor(Math.random()*GUEST_ADJ.length)];
    const n = GUEST_NOUN[Math.floor(Math.random()*GUEST_NOUN.length)];
    const num = Math.floor(10 + Math.random()*90);
    return `${a} ${n}${num}`;
}

/* ═══ পাসওয়ার্ড হ্যাশ (SHA-256) ═══ */
async function hashPassword(password){
    const data = new TextEncoder().encode(password + '::' + GUEST_SALT);
    const buf  = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2,'0')).join('');
}

/* ═══ Guest স্টোরেজ ═══ */
function loadDemoGuests(){
    try { return JSON.parse(localStorage.getItem('moi_demo_guests') || '{}'); } catch(e){ return {}; }
}
function saveDemoGuest(uid, data){
    const all = loadDemoGuests();
    all[uid] = data;
    try { localStorage.setItem('moi_demo_guests', JSON.stringify(all)); } catch(e){}
}

/* ═══ Guest State ═══ */
let guestState = { mode:'create', deviceId:'', uid:'', name:'', avatar:'', moiId:'', existingData:null };

/* ═══ Password Eye Toggle ═══ */
$('toggleGuestPass').addEventListener('click', () => {
    const inp  = $('guestPassword');
    const icon = $('toggleGuestPass');
    if (inp.type === 'password'){
        inp.type = 'text';
        icon.classList.remove('fa-eye'); icon.classList.add('fa-eye-slash');
    } else {
        inp.type = 'password';
        icon.classList.remove('fa-eye-slash'); icon.classList.add('fa-eye');
    }
});

/* ═══ Back to Login ═══ */
$('guestBackBtn').addEventListener('click', () => {
    $('guestPassword').value = '';
    $('guestPasswordConfirm').value = '';
    guestState.uid = '';
    guestState.existingData = null;
    showView('login');
});

/* ═══ Guest Button Click ═══ */
$('guestBtn').addEventListener('click', async () => {
    const btn = $('guestBtn');
    const original = btn.innerHTML;
    btn.innerHTML = `<span class="loading"></span><span>Checking…</span>`;
    btn.disabled = true;
    try {
        const deviceId = getDeviceId();
        guestState.deviceId = deviceId;
        const existingUid = ls_get(KEY.guestUid, null);
        const guests = loadDemoGuests();

        if (existingUid && guests[existingUid]){
            const u = guests[existingUid];
            guestState.mode = 'login';
            guestState.uid = existingUid;
            guestState.name = u.name;
            guestState.avatar = u.photo;
            guestState.moiId = u.moiId;
            guestState.existingData = u;

            $('guestTitle').textContent = 'WELCOME BACK';
            $('guestSub').textContent = 'Enter your password to login';
            $('guestAvatar').innerHTML = `<img src="${u.photo}" alt="">`;
            $('guestName').textContent = u.name;
            $('guestMoiId').textContent = u.moiId;
            $('guestPassLabel').textContent = 'Enter Password';
            $('guestConfirmGroup').style.display = 'none';
            $('guestNote').className = 'guest-note info';
            $('guestNote').innerHTML = `<i class="fa-solid fa-circle-info"></i><span>আপনার আগের অ্যাকাউন্টে ঢুকতে পাসওয়ার্ড দিন। ভুলে গেলে নতুন অ্যাকাউন্ট বানাতে হবে।</span>`;
            $('guestSubmitText').textContent = 'Login';
            $('guestPassword').value = '';
            $('guestPasswordConfirm').value = '';
            showView('guest');
        } else {
            await createNewGuest();
        }
    } catch (err){
        console.error('[DEMO GUEST] failed:', err);
        alert('Guest failed: ' + err.message);
    } finally {
        btn.innerHTML = original;
        btn.disabled = false;
    }
});

/* ═══ নতুন Guest বানানো ═══ */
async function createNewGuest(){
    const uid = generateUid('guest');
    const name = randomGuestName();
    const avatar = randomDiceAvatar(uid);
    const moiId = generateMoiId();

    guestState.mode = 'create';
    guestState.uid = uid;
    guestState.name = name;
    guestState.avatar = avatar;
    guestState.moiId = moiId;
    guestState.existingData = null;

    $('guestTitle').textContent = 'GUEST ACCOUNT';
    $('guestSub').textContent = 'Set a password to activate';
    $('guestAvatar').innerHTML = `<img src="${avatar}" alt="">`;
    $('guestName').textContent = name;
    $('guestMoiId').textContent = moiId;
    $('guestPassLabel').textContent = 'Set Password';
    $('guestConfirmGroup').style.display = '';
    $('guestNote').className = 'guest-note';
    $('guestNote').innerHTML = `<i class="fa-solid fa-triangle-exclamation"></i><span>এই পাসওয়ার্ড অবশ্যই সংরক্ষণ করুন। একই ফোন থেকে দ্বিতীয়বার গেস্ট একাউন্টে ঢুকতে এই পাসওয়ার্ড দরকার হবে।</span>`;
    $('guestSubmitText').textContent = 'Create Account';
    $('guestPassword').value = '';
    $('guestPasswordConfirm').value = '';
    showView('guest');
}

/* ═══ Guest Submit (Login অথবা Create) ═══ */
$('guestSubmitBtn').addEventListener('click', async () => {
    const pass = $('guestPassword').value;
    if (!pass || pass.length < 4){ alert('পাসওয়ার্ড কমপক্ষে ৪ অক্ষরের হতে হবে।'); return; }
    const btn = $('guestSubmitBtn');
    const original = btn.innerHTML;

    /* ============ LOGIN MODE ============ */
    if (guestState.mode === 'login'){
        btn.innerHTML = `<span class="loading"></span><span>Logging in…</span>`;
        btn.disabled = true;
        try {
            const guests = loadDemoGuests();
            const u = guests[guestState.uid];
            if (!u){ alert('অ্যাকাউন্ট পাওয়া যায়নি।'); btn.innerHTML = original; btn.disabled = false; return; }
            const hash = await hashPassword(pass);
            if (hash !== u.passwordHash){
                alert('❌ ভুল পাসওয়ার্ড!');
                btn.innerHTML = original;
                btn.disabled = false;
                return;
            }
            showUidBadge(u.moiId);
            redirectToHomepage({
                uid: u.uid, name: u.name, photo: u.photo, email: '',
                country: u.country || '', voice: u.voice || '',
                moiId: u.moiId, guest: '1', diamonds: u.diamonds || 1000
            });
        } catch(err){
            console.error(err);
            alert('Login failed: ' + err.message);
            btn.innerHTML = original;
            btn.disabled = false;
        }
        return;
    }

    /* ============ CREATE MODE ============ */
    const pass2 = $('guestPasswordConfirm').value;
    if (pass !== pass2){
        alert('দুইটি পাসওয়ার্ড মিলছে না।');
        return;
    }
    btn.innerHTML = `<span class="loading"></span><span>Creating…</span>`;
    btn.disabled = true;

    try {
        const passwordHash = await hashPassword(pass);
        const guestData = {
            uid: guestState.uid,
            name: guestState.name,
            photo: guestState.avatar,
            moiId: guestState.moiId,
            country: '', voice: '',
            passwordHash,
            isGuest: true,
            isDemo: true,
            diamonds: 1000,
            createdAt: Date.now()
        };
        saveDemoGuest(guestState.uid, guestData);
        saveUser(guestState.uid, guestData);
        ls_set(KEY.guestUid, guestState.uid);

        pendingUser = guestData;
        $('profileName').textContent = guestState.name;
        $('profileAvatar').innerHTML = `<img src="${guestState.avatar}" alt="">`;
        $('countrySelect').value = '';
        selectedVoice = '';
        document.querySelectorAll('.voice-btn').forEach(b => b.classList.remove('active'));
        showView('profile');
    } catch(err){
        console.error(err);
        alert('Creation failed: ' + err.message);
        btn.innerHTML = original;
        btn.disabled = false;
    }
});