/* home/home.js — Home পেজের মূল কাজ (Init, User, Chat) */

console.log('[MOI HOME] DEMO MODE');

/* ═══ লিংক ═══ */
window.LINKS = {
    room      : URLS.room,
    ownerRoom : URLS.room,
    chat      : URLS.chat,
    me        : URLS.me
};

/* ═══ ইউজার স্টেট ═══ */
window.user = { uid:'', name:'User', photo:'', email:'', country:'', voice:'', moiId:'', myRoomUid:'', diamonds:1000 };
window.userReady = false;

/* ═══ URL থেকে ইউজার পড়া ═══ */
function readFromURL(){
    const p = new URLSearchParams(location.search);
    const uid = p.get('uid');
    if (!uid) return null;
    return {
        uid,
        name:p.get('name')||'User',
        photo:p.get('photo')||'',
        email:p.get('email')||'',
        country:p.get('country')||'',
        voice:p.get('voice')||'',
        moiId:p.get('moiId')||'',
        diamonds: Number(p.get('diamonds')) || 1000
    };
}

/* ═══ ইউজার সেট করা ═══ */
function initUser(){
    let base = readFromURL();
    if (!base) base = getCurrentUser();
    if (!base || !base.uid) base = ensureSampleUser();
    if (!base || !base.uid){
        document.getElementById('userNameDisplay').textContent = 'Not Logged In';
        document.getElementById('userDisplayId').textContent = 'Please sign in';
        return false;
    }

    Object.assign(window.user, base);

    const fresh = getUser(window.user.uid);
    if (fresh){
        window.user.name = fresh.name || window.user.name;
        window.user.photo = fresh.photo || fresh.avatar || window.user.photo;
        window.user.email = fresh.email || window.user.email;
        window.user.country = fresh.country || window.user.country;
        window.user.voice = fresh.voice || window.user.voice;
        window.user.moiId = fresh.moiId || window.user.moiId;
        window.user.myRoomUid = fresh.myRoomUid || window.user.myRoomUid;
        window.user.diamonds = fresh.diamonds ?? window.user.diamonds;
    }

    setCurrentUser({
        uid: window.user.uid,
        name: window.user.name,
        photo: window.user.photo,
        email: window.user.email,
        country: window.user.country,
        voice: window.user.voice,
        moiId: window.user.moiId,
        diamonds: window.user.diamonds || 1000
    });

    window.userReady = true;
    return true;
}

/* ═══ ইউজার রেন্ডার ═══ */
function renderUser(){
    document.getElementById('userNameDisplay').textContent = window.user.name || 'User';
    document.getElementById('userDisplayId').textContent = 'ID: ' + (window.user.moiId || (window.user.uid ? window.user.uid.slice(0,8) : '---'));
    if (window.user.photo) document.getElementById('userAvatar').src = window.user.photo;
}

/* ═══ Nav Active State ঠিক করা ═══ */
function setNavActive(which){
    const room = document.getElementById('navRoom');
    const chat = document.getElementById('navChat');
    const me   = document.getElementById('navMe');
    if (room) room.classList.toggle('active', which === 'room');
    if (chat) chat.classList.toggle('active', which === 'chat');
    if (me)   me.classList.toggle('active', which === 'me');
}

/* ═══ Chat ═══ */
let chatOpen = false;

window.openChat = (targetUid, targetName) => {
    const overlay = document.getElementById('chatOverlay');
    const frame = document.getElementById('chatFrame');
    const loading = document.getElementById('chatLoading');
    loading.classList.remove('hidden');

    let url = window.LINKS.chat;
    if (targetUid){
        const u = new URL(window.LINKS.chat, location.href);
        u.searchParams.set('targetUid', targetUid);
        if (targetName) u.searchParams.set('targetName', targetName);
        url = u.toString();
    }
    frame.src = url;
    frame.onload = () => loading.classList.add('hidden');
    overlay.classList.add('show');
    chatOpen = true;
    document.body.style.overflow = 'hidden';

    setNavActive('chat');
};

window.closeChat = () => {
    document.getElementById('chatOverlay').classList.remove('show');
    chatOpen = false;
    document.body.style.overflow = '';
    setTimeout(() => { document.getElementById('chatFrame').src = 'about:blank'; }, 300);

    setNavActive('room');
};

/* ═══ Bottom Nav ═══ */
function initNav(){
    document.getElementById('navRoom').addEventListener('click', () => {
        if (chatOpen){ closeChat(); return; }
        setNavActive('room');
        window.scrollTo({ top:0, behavior:'smooth' });
    });

    document.getElementById('navChat').addEventListener('click', () => {
        if (chatOpen) closeChat();
        else window.openChat();
    });

    document.getElementById('navMe').addEventListener('click', () => {
        if (chatOpen) closeChat();
        setNavActive('me');
        setTimeout(() => location.href = window.LINKS.me, 120);
    });
}

/* ═══ সব শুরু করা ═══ */
(async () => {
    try {
        ensureDemoUsers();
        if (typeof ensureDemoRooms === 'function') ensureDemoRooms();

        const ok = initUser();
        if (!ok){ renderBannerEmpty(); return; }

        renderUser();
        loadMyRoom();
        initRoomsUI();
        initModal();
        initNav();

        setNavActive('room');

        console.log('%c[MOI HOME] ✅ ready — ' + window.user.name + ' (' + window.user.moiId + ')', 'color:#20e3b2;font-weight:800');
    } catch(err){
        console.error('[INIT] fatal:', err);
        renderBannerEmpty();
    }
})();