/* home/modal.js — Create Room মডাল + Cropper */

console.log('[MOI] modal.js loaded');

let cropper = null;
let currentRoomUid = '';

function generateRoomUid(){
    const rooms = getAllRooms();
    for (let i = 0; i < 25; i++){
        const num = String(Math.floor(100000 + Math.random() * 900000));
        if (!rooms[num]) return num;
    }
    return String(Date.now()).slice(-6);
}

function initModal(){
    const imageInput = document.getElementById('modalImgInput');
    const cropperModal = document.getElementById('cropperModal');
    const cropperImage = document.getElementById('cropperImage');
    const uploadBox = document.getElementById('uploadBox');
    const croppedPreview = document.getElementById('croppedPreview');

    uploadBox.addEventListener('click', () => imageInput.click());

    imageInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = (event) => {
            cropperImage.src = event.target.result;
            cropperModal.classList.add('show');
            if (cropper) cropper.destroy();
            cropper = new Cropper(cropperImage, { aspectRatio:1, viewMode:1, background:false, autoCropArea:0.8 });
        };
        reader.readAsDataURL(file);
    });

    document.getElementById('cropSaveBtn').addEventListener('click', () => {
        if (!cropper) return;
        const canvas = cropper.getCroppedCanvas({ width:300, height:300 });
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        croppedPreview.src = dataUrl;
        croppedPreview.style.display = 'block';
        uploadBox.querySelector('.fa-plus').style.display = 'none';
        cropperModal.classList.remove('show');
        cropper.destroy();
        cropper = null;
    });

    document.getElementById('cropCancelBtn').addEventListener('click', () => {
        cropperModal.classList.remove('show');
        if (cropper){ cropper.destroy(); cropper = null; }
        imageInput.value = '';
    });

    /* ═══ Mine button ═══ */
    async function handleMineClick(e){
        if (e) e.stopPropagation();
        if (!window.userReady){ alert('ইউজার লোড হচ্ছে...'); return; }
        if (window.user.myRoomUid){
            location.href = window.LINKS.room + '?room=' + encodeURIComponent(window.user.myRoomUid);
            return;
        }
        currentRoomUid = generateRoomUid();
        document.getElementById('modalRoomUid').value = currentRoomUid;
        document.getElementById('modalGroupName').value = '';
        document.getElementById('modalCountry').value = '';
        croppedPreview.src = '';
        croppedPreview.style.display = 'none';
        const plus = uploadBox.querySelector('.fa-plus');
        if (plus) plus.style.display = '';
        document.getElementById('roomModal').classList.add('show');
    }

    document.getElementById('roomBanner').addEventListener('click', (e) => {
        if (e.target.closest('#mineBtn')) return;
        handleMineClick(e);
    });
    document.getElementById('mineBtn').addEventListener('click', handleMineClick);

    document.getElementById('modalCloseBtn').addEventListener('click', () => {
        document.getElementById('roomModal').classList.remove('show');
    });

    /* ═══ Submit ═══ */
    document.getElementById('modalSubmitBtn').addEventListener('click', () => {
        const groupName = document.getElementById('modalGroupName').value.trim();
        const country = document.getElementById('modalCountry').value;
        const croppedImgBase64 = croppedPreview.src || '';
        if (!groupName){ alert('অনুগ্রহ করে গ্রুপের নাম দিন।'); return; }
        if (!window.user.uid){ alert('ইউজার লোড হয়নি।'); return; }

        const btn = document.getElementById('modalSubmitBtn');
        const oldTxt = btn.innerHTML;
        btn.innerHTML = 'Saving...';
        btn.disabled = true;

        const roomData = {
            name: groupName,
            logo: croppedImgBase64,
            country: country || 'Unknown',
            id: currentRoomUid,
            level: 1,
            owner: { uid: window.user.uid, name: window.user.name || 'User', avatar: window.user.photo || '' },
            createdAt: Date.now()
        };

        try {
            saveRoom(currentRoomUid, roomData);
            saveUser(window.user.uid, { myRoomUid: currentRoomUid });
            window.user.myRoomUid = currentRoomUid;
            renderBannerWithRoom(roomData);
            document.getElementById('roomModal').classList.remove('show');
            setTimeout(() => {
                location.href = window.LINKS.room + '?room=' + encodeURIComponent(currentRoomUid);
            }, 300);
        } catch(err){
            alert('সেভ করতে সমস্যা: ' + err.message);
            btn.innerHTML = oldTxt;
            btn.disabled = false;
        }
    });
}

window.initModal = initModal;
window.generateRoomUid = generateRoomUid;