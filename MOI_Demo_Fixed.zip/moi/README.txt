MOI — DEMO APP (সব ডেটা localStorage-এ)

চালানোর নিয়ম (file:// দিয়ে খুললে গিফট/অ্যানিমেশন লোড হবে না, লোকাল সার্ভার লাগবে):
  1) এই ফোল্ডারে টার্মিনাল খুলুন
  2) python3 -m http.server 8000
  3) ব্রাউজারে (মোবাইল ভিউ) খুলুন: http://localhost:8000/login/index.html

ফ্লো: Login (Guest) → Profile সেটআপ → Home → Room / Create Room → Messages → Me
