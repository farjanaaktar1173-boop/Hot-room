/* ═══════════════════════════════════════════════════════════
   shared/demo-data.js
   ডেমো ইউজার, ১০টা ফেক রুম, ডেমো বন্ধু বানানো
   ═══════════════════════════════════════════════════════════ */

console.log('[MOI] demo-data.js loaded');

/* ═══════════════ ডেমো ইউজারের নাম ═══════════════ */
const DEMO_NAMES = [
    'Arif', 'Fatima', 'Rahul', 'Priya', 'Ahmed', 'Sara',
    'Kabir', 'Nadia', 'Hasan', 'Zara', 'Ravi', 'Maya',
    'Imran', 'Layla', 'Samir', 'Nisha', 'Tanvir', 'Rupa',
    'Sumon', 'Jannat', 'Rifat', 'Mitu', 'Shakib', 'Ayesha',
    'Rony', 'Tania', 'Fahim', 'Lubna', 'Nabil', 'Rina'
];

/* ═══════════════ ডেমো ইউজারের ছবি ═══════════════ */
const DEMO_AVATARS = [
    'https://i.pravatar.cc/200?img=1',
    'https://i.pravatar.cc/200?img=5',
    'https://i.pravatar.cc/200?img=9',
    'https://i.pravatar.cc/200?img=12',
    'https://i.pravatar.cc/200?img=15',
    'https://i.pravatar.cc/200?img=20',
    'https://i.pravatar.cc/200?img=25',
    'https://i.pravatar.cc/200?img=32',
    'https://i.pravatar.cc/200?img=40',
    'https://i.pravatar.cc/200?img=45',
    'https://i.pravatar.cc/200?img=50',
    'https://i.pravatar.cc/200?img=55',
    'https://i.pravatar.cc/200?img=60',
    'https://i.pravatar.cc/200?img=65',
    'https://i.pravatar.cc/200?img=68',
    'https://i.pravatar.cc/200?img=70',
    'https://i.pravatar.cc/200?img=3',
    'https://i.pravatar.cc/200?img=8',
    'https://i.pravatar.cc/200?img=14',
    'https://i.pravatar.cc/200?img=18',
    'https://i.pravatar.cc/200?img=23',
    'https://i.pravatar.cc/200?img=27',
    'https://i.pravatar.cc/200?img=30',
    'https://i.pravatar.cc/200?img=36',
    'https://i.pravatar.cc/200?img=42',
    'https://i.pravatar.cc/200?img=48',
    'https://i.pravatar.cc/200?img=53',
    'https://i.pravatar.cc/200?img=58',
    'https://i.pravatar.cc/200?img=63',
    'https://i.pravatar.cc/200?img=66'
];

/* ═══════════════ ১০টা ফেক রুম — আলাদা owner + আলাদা listeners ═══════════════ */
const DEMO_ROOMS = [
    { id:'S1001', name:'Dhaka Music FM',    country:'Bangladesh', level:5, listeners:45, micCount:8, ownerName:'Rafiq Islam',     ownerAvatar:'https://i.pravatar.cc/200?img=11' },
    { id:'S1002', name:'Mumbai Chat Room',  country:'India',      level:4, listeners:38, micCount:7, ownerName:'Aditi Verma',      ownerAvatar:'https://i.pravatar.cc/200?img=44' },
    { id:'S1003', name:'Karachi Beats',     country:'Pakistan',   level:3, listeners:22, micCount:5, ownerName:'Bilal Khan',       ownerAvatar:'https://i.pravatar.cc/200?img=57' },
    { id:'S1004', name:'Dubai Night FM',    country:'UAE',        level:5, listeners:42, micCount:8, ownerName:'Sheikh Hamdan',    ownerAvatar:'https://i.pravatar.cc/200?img=13' },
    { id:'S1005', name:'London Vibes',      country:'UK',         level:2, listeners:14, micCount:4, ownerName:'Emily Watson',     ownerAvatar:'https://i.pravatar.cc/200?img=47' },
    { id:'S1006', name:'Tokyo Lounge',      country:'Japan',      level:4, listeners:28, micCount:6, ownerName:'Yuki Tanaka',      ownerAvatar:'https://i.pravatar.cc/200?img=22' },
    { id:'S1007', name:'Seoul K-Pop',       country:'South Korea',level:3, listeners:19, micCount:5, ownerName:'Min-Ji Park',      ownerAvatar:'https://i.pravatar.cc/200?img=26' },
    { id:'S1008', name:'Cairo Chill',       country:'Egypt',      level:2, listeners:11, micCount:3, ownerName:'Amir Hassan',      ownerAvatar:'https://i.pravatar.cc/200?img=61' },
    { id:'S1009', name:'Istanbul Mix',      country:'Turkey',     level:4, listeners:26, micCount:6, ownerName:'Zeynep Yilmaz',    ownerAvatar:'https://i.pravatar.cc/200?img=49' },
    { id:'S1010', name:'NYC Party',         country:'USA',        level:5, listeners:35, micCount:7, ownerName:'Michael Brown',    ownerAvatar:'https://i.pravatar.cc/200?img=59' }
];

/* ═══════════════ ইউনিক আইডি বানানো ═══════════════ */
function generateMoiId(){
    const all = getAllUsers();
    const used = new Set(Object.values(all).map(u => u.moiId).filter(Boolean));
    for (let i = 0; i < 50; i++){
        const num = String(Math.floor(100000 + Math.random() * 900000));
        if (!used.has(num)) return num;
    }
    return String(Date.now()).slice(-6);
}

/* ═══════════════ র‍্যান্ডম ইউজার আইডি ═══════════════ */
function generateUid(prefix){
    prefix = prefix || 'u';
    return prefix + '_' + Date.now().toString(36) + '_' + Math.random().toString(36).slice(2, 7);
}

/* ═══════════════ র‍্যান্ডম অ্যাভাটার (DiceBear) ═══════════════ */
function randomDiceAvatar(seed){
    return `https://api.dicebear.com/7.x/adventurer/svg?seed=${encodeURIComponent(seed)}&backgroundType=gradientLinear&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf`;
}

/* ═══════════════ ডেমো ইউজার তৈরি (প্রথমবার) ═══════════════ */
function ensureDemoUsers(){
    const all = getAllUsers();
    const existing = Object.values(all).filter(u => u.isFake);
    if (existing.length >= 30) return;

    DEMO_NAMES.forEach((name, i) => {
        const uid = 'fake_' + (i + 1);
        if (all[uid]) return;
        all[uid] = {
            uid: uid,
            name: name,
            photo: DEMO_AVATARS[i % DEMO_AVATARS.length],
            email: name.toLowerCase() + '@demo.com',
            moiId: String(200000 + i * 7777).slice(0, 6),
            country: ['Bangladesh','India','Pakistan','UAE','UK','Japan','South Korea','Egypt','Turkey','USA'][i % 10],
            voice: ['Male','Female','Neutral'][i % 3],
            diamonds: Math.floor(Math.random() * 5000) + 1000,
            isFake: true,
            isDemo: true,
            createdAt: Date.now() - Math.floor(Math.random() * 30 * 24 * 60 * 60 * 1000)
        };
    });
    setAllUsers(all);
}

/* ═══════════════ ১০টা রুম + owner + seats + listeners সেভ করা ═══════════════ */
function ensureDemoRooms(){
    const rooms = ls_get('moi_demo_rooms', {}) || {};
    const users = getAllUsers();

    DEMO_ROOMS.forEach((r, idx) => {
        const ownerUid = 'demo_owner_' + r.id;

        /* ----- owner কে user হিসেবে সেভ ----- */
        if (!users[ownerUid]){
            users[ownerUid] = {
                uid: ownerUid,
                name: r.ownerName,
                photo: r.ownerAvatar,
                email: r.ownerName.toLowerCase().replace(/\s+/g,'.') + '@moi.demo',
                moiId: String(300000 + idx * 11111).slice(0, 6),
                country: r.country,
                voice: 'Neutral',
                diamonds: 5000 + idx * 1000,
                isFake: true,
                isDemo: true,
                isOwner: true,
                createdAt: Date.now()
            };
        }

        /* ----- room info সেভ ----- */
        if (!rooms[r.id]){
            rooms[r.id] = {
                id: r.id,
                name: r.name,
                country: r.country,
                level: r.level,
                logo: `https://picsum.photos/seed/${r.id}/400/460`,
                listeners: r.listeners,
                owner: { uid: ownerUid, name: r.ownerName, avatar: r.ownerAvatar },
                isDemo: true,
                createdAt: Date.now() - (10 - idx) * 24 * 60 * 60 * 1000
            };
        }

        /* ----- seats + listeners সেভ (যদি না থাকে) ----- */
        const seatsKey = 'moi_room_' + r.id + '_seats';
        const listenersKey = 'moi_room_' + r.id + '_listeners';
        if (!ls_get(seatsKey, null)){
            const { seats, listeners } = buildDemoRoomState(r, ownerUid, idx);
            ls_set(seatsKey, seats);
            ls_set(listenersKey, listeners);
        }
    });

    ls_set('moi_demo_rooms', rooms);
    setAllUsers(users);
}

/* ═══════════════ একটা রুমের seats + listeners বানানো ═══════════════ */
function buildDemoRoomState(room, ownerUid, roomIndex){
    const owner = {
        uid: ownerUid,
        name: room.ownerName,
        avatar: room.ownerAvatar,
        role: 'owner',
        mic: true,
        locked: false,
        coins: Math.floor(Math.random() * 3000) + 500,
        started: Date.now() - 3600000
    };

    const seats = new Array(10).fill(null);
    seats[0] = owner;

    const listeners = [{
        uid: ownerUid,
        name: room.ownerName,
        avatar: room.ownerAvatar,
        role: 'owner',
        joined: Date.now() - 3600000,
        isFake: true
    }];

    /* মাইকে কতজন বসবে = room.micCount (max 9) */
    const micCount = Math.min(room.micCount, 9);
    for (let i = 1; i <= micCount; i++){
        const nameIdx = (roomIndex * 3 + i) % DEMO_NAMES.length;
        const avIdx   = (roomIndex * 3 + i) % DEMO_AVATARS.length;
        const uid = `fake_${room.id}_seat_${i}`;
        const isAdmin = (i === 1);
        const micOn = Math.random() > 0.25;

        seats[i] = {
            uid,
            name: DEMO_NAMES[nameIdx],
            avatar: DEMO_AVATARS[avIdx],
            role: isAdmin ? 'admin' : 'member',
            mic: micOn,
            locked: false,
            coins: Math.floor(Math.random() * 1500),
            started: Date.now() - (i * 300000)
        };

        listeners.push({
            uid,
            name: DEMO_NAMES[nameIdx],
            avatar: DEMO_AVATARS[avIdx],
            role: isAdmin ? 'admin' : 'member',
            joined: Date.now() - (i * 300000),
            isFake: true
        });
    }

    /* বাকি listeners (শুধু শুনছে, মাইকে নেই) */
    const extraCount = Math.max(0, room.listeners - listeners.length);
    const cap = Math.min(extraCount, 20);
    for (let i = 0; i < cap; i++){
        const nameIdx = (roomIndex * 5 + i + 10) % DEMO_NAMES.length;
        const avIdx   = (roomIndex * 5 + i + 10) % DEMO_AVATARS.length;
        const uid = `fake_${room.id}_lsn_${i}`;
        listeners.push({
            uid,
            name: DEMO_NAMES[nameIdx] + (i > 5 ? i : ''),
            avatar: DEMO_AVATARS[avIdx],
            role: 'member',
            joined: Date.now() - (i * 60000),
            isFake: true
        });
    }

    /* শেষ seat locked */
    seats[9] = { locked: true, by: 'System' };

    return { seats, listeners };
}

/* ═══════════════ ফেক স্যাম্পল ইউজার (লগইন ছাড়া) ═══════════════ */
function ensureSampleUser(){
    const uid = ls_get(KEY.sampleUid, null);
    if (uid){
        const u = getUser(uid);
        if (u) return u;
    }
    const newUid = generateUid('sample');
    const moiId  = generateMoiId();
    const photo  = randomDiceAvatar(newUid);
    const data = {
        uid: newUid,
        name: 'Sample User',
        photo: photo,
        email: '',
        moiId: moiId,
        country: 'Bangladesh',
        voice: 'Neutral',
        diamonds: 1000,
        isSample: true,
        createdAt: Date.now()
    };
    saveUser(newUid, data);
    ls_set(KEY.sampleUid, newUid);
    return data;
}

/* ═══════════════ ডেমো রুম — হোম পেজে দেখানোর জন্য ═══════════════ */
function getDemoRoomsForDisplay(){
    return DEMO_ROOMS.map(r => {
        const ownerUid = 'demo_owner_' + r.id;
        return {
            id: r.id,
            name: r.name,
            logo: `https://picsum.photos/seed/${r.id}/400/460`,
            img:  `https://picsum.photos/seed/${r.id}/400/460`,
            country: r.country,
            level: r.level,
            ownerUid: ownerUid,
            ownerName: r.ownerName,
            listeners: r.listeners,
            createdAt: 0,
            isDemo: true
        };
    });
}

/* ═══════════════ ডেমো চ্যাট মেসেজ (প্রথমবার) ═══════════════ */
function seedDemoChat(uidA, uidB){
    if (!uidA || !uidB) return;
    const chatKey = 'moi_chat_' + [uidA, uidB].sort().join('__');
    if (ls_get(chatKey, null)) return;

    const now = Date.now();
    const messages = [
        { id: 'm1', senderUid: uidB, type:'text', content:'হ্যালো! কেমন আছেন?', time: '10:15', ts: now - 3600000 },
        { id: 'm2', senderUid: uidA, type:'text', content:'ভালো আছি, আপনি?', time: '10:16', ts: now - 3500000 },
        { id: 'm3', senderUid: uidB, type:'text', content:'আলহামদুলিল্লাহ 😊', time: '10:17', ts: now - 3400000 }
    ];
    ls_set(chatKey, messages);
}

/* ═══════════════ সব উইন্ডোতে ═══════════════ */
window.DEMO_NAMES              = DEMO_NAMES;
window.DEMO_AVATARS            = DEMO_AVATARS;
window.DEMO_ROOMS              = DEMO_ROOMS;
window.generateMoiId           = generateMoiId;
window.generateUid             = generateUid;
window.randomDiceAvatar        = randomDiceAvatar;
window.ensureDemoUsers         = ensureDemoUsers;
window.ensureDemoRooms         = ensureDemoRooms;
window.buildDemoRoomState      = buildDemoRoomState;
window.ensureSampleUser        = ensureSampleUser;
window.getDemoRoomsForDisplay  = getDemoRoomsForDisplay;
window.seedDemoChat            = seedDemoChat;