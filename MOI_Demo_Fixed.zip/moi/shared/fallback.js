/* ═══ ছবি লোড না হলে নিজে থেকেই সুন্দর fallback avatar ═══ */
(function(){
    const FALLBACK = "data:image/svg+xml;utf8," + encodeURIComponent(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#20e3b2"/><stop offset="1" stop-color="#7c3aed"/></linearGradient></defs><rect width="100" height="100" fill="url(#g)"/><circle cx="50" cy="38" r="17" fill="rgba(255,255,255,.9)"/><path d="M16 92c4-22 19-32 34-32s30 10 34 32z" fill="rgba(255,255,255,.9)"/></svg>');
    window.FALLBACK_IMG = FALLBACK;
    document.addEventListener('error', (e) => {
        const t = e.target;
        if (t && t.tagName === 'IMG' && t.src !== FALLBACK && !t.dataset.fb){
            t.dataset.fb = '1';
            t.src = FALLBACK;
        }
    }, true);
})();
