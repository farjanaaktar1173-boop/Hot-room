/* chat/demo-bot.js — ডেমো ইউজাররা (fake_*) আসল মানুষের মতো আচরণ করে:
   ১) Friend request পাঠালে কিছুক্ষণ পরে Accept করে
   ২) মেসেজ পাঠালে seen হয় এবং রিপ্লাই দেয় */

console.log('[MOI] demo-bot.js loaded');

const BOT_REPLIES = [
    'হ্যালো! কেমন আছেন? 😊', 'আরে আপনি! অনেক দিন পর 😄', 'আমি এখন রুমে আছি, আসুন 🎙️',
    'হা হা, ঠিক বলেছেন 😂', 'ধন্যবাদ! 💖', 'আজকের রুমটা দারুণ চলছে 🔥',
    'একটু পরে কথা বলি? ব্যস্ত আছি', 'ভালো লাগলো শুনে 👍', 'আপনার গিফটের জন্য ধন্যবাদ 🎁',
    'চলুন একসাথে PK খেলি! ⚔️', 'Hey! Nice to meet you 👋', 'Sounds great! 🎉'
];

function isBotUid(uid){
    if (!uid) return false;
    if (String(uid).startsWith('fake_')) return true;
    const u = (typeof getUser === 'function') ? getUser(uid) : null;
    return !!(u && (u.isFake || u.isDemoBot));
}

/* ───── Friend request → auto accept ───── */
(function(){
    const origSend = window.sendFriendRequest;
    window.sendFriendRequest = function(){
        const target = window.currentChatUid;
        const meUid = window.me && window.me.uid;
        origSend.apply(this, arguments);
        if (!target || !meUid || !isBotUid(target)) return;

        setTimeout(() => {
            const theirReqs = ls_get('moi_friend_requests_' + target, {}) || {};
            delete theirReqs[meUid];
            ls_set('moi_friend_requests_' + target, theirReqs);

            const mine = ls_get('moi_friends_' + meUid, {}) || {};
            mine[target] = true;
            ls_set('moi_friends_' + meUid, mine);
            const theirs = ls_get('moi_friends_' + target, {}) || {};
            theirs[meUid] = true;
            ls_set('moi_friends_' + target, theirs);
            const sent = ls_get('moi_sent_requests_' + meUid, {}) || {};
            delete sent[target];
            ls_set('moi_sent_requests_' + meUid, sent);

            const u = getUser(target) || {};
            toast('🎉 ' + (u.name || 'User') + ' আপনার অনুরোধ Accept করেছেন');
            loadFriendsData();
            if (typeof updateFriendStatus === 'function' && window.currentChatUid === target) updateFriendStatus();
            renderList();
            updateReqBadge();
        }, 2200);
    };
})();

/* ───── Message → seen + auto reply ───── */
(function(){
    const origPush = window.pushMsg;
    window.pushMsg = function(payload){
        const target = window.currentChatUid;
        const meUid = window.me && window.me.uid;
        origPush.apply(this, arguments);
        if (!target || !meUid || !isBotUid(target)) return;

        const sentId = (loadMessages().slice(-1)[0] || {}).id;

        /* seen tick */
        setTimeout(() => {
            if (window.currentChatUid !== target) return;
            const list = loadMessages();
            const m = list.find(x => x.id === sentId);
            if (m){ m.seen = true; saveMessages(list); renderAllMessages(); }
        }, 900);

        /* bot reply */
        setTimeout(() => {
            const text = BOT_REPLIES[Math.floor(Math.random() * BOT_REPLIES.length)];
            const u = getUser(target) || {};
            const key = 'moi_chat_' + roomId(meUid, target);
            const list = ls_get(key, []) || [];
            const msg = {
                id: 'm_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
                type: 'text', content: text,
                senderUid: target, senderName: u.name || 'User',
                time: nowTime(), ts: Date.now(), delivered: true
            };
            list.push(msg);
            ls_set(key, list);

            const viewing = window.currentChatUid === target;
            if (viewing) appendMessage(msg), (document.getElementById('chatBody').scrollTop = 1e9);

            chatMetas[target] = {
                lastMessage: text, lastTime: Date.now(), lastSender: target, lastType: 'text',
                unread: viewing ? 0 : ((chatMetas[target] && chatMetas[target].unread) || 0) + 1
            };
            saveFriendsData();
            renderList();
        }, 1600 + Math.random() * 1400);
    };
})();
