/* room/main.js — Room বুট + init */

console.log('[ROOM] main.js loaded');

/* ═══ User bootstrap ═══ */
(function bootstrapUser(){
    let u = getCurrentUser();
    if (!u || !u.uid){
        const p = new URLSearchParams(location.search);
        if (p.get('uid')){
            u = {
                uid: p.get('uid'),
                name: p.get('name') || 'User',
                photo: p.get('photo') || GUEST_AVATAR,
                moiId: p.get('moiId') || '',
                country: p.get('country') || '',
                voice: p.get('voice') || '',
                diamonds: Number(p.get('diamonds')) || 1000
            };
        }
    }
    if (!u || !u.uid){
        /* Sample ইউজার বানাও যাতে কিছু দেখা যায় */
        const fresh = getUser('sample_fallback');
        if (fresh) u = fresh;
        else {
            const uid = 'sample_' + Date.now().toString(36);
            const moiId = String(Math.floor(100000 + Math.random() * 900000));
            u = {
                uid, name:'Sample User',
                photo: `https://api.dicebear.com/7.x/adventurer/svg?seed=${uid}&backgroundType=gradientLinear`,
                moiId, country:'Bangladesh', voice:'Neutral', diamonds:1000, isSample:true
            };
            saveUser(uid, u);
        }
    }
    if (!u || !u.uid) return;

    myProfile = {
        uid: u.uid,
        name: u.name || 'User',
        avatar: u.photo || u.avatar || GUEST_AVATAR,
        email: u.email || '',
        moiId: u.moiId || '',
        country: u.country || '',
        voice: u.voice || '',
        diamonds: u.diamonds ?? 1000
    };
    const av = $('my-avatar-top');
    if (av) av.src = myProfile.avatar;
    if (typeof refreshTopBarRing === 'function') refreshTopBarRing();

    /* ═══════════════════════════════════════════════════════════
       🔄 FRESH RESET — Room এ ঢুকলেই সব fresh
       ═══════════════════════════════════════════════════════════ */
    try {
        if (typeof resetRoomStorage === 'function'){
            resetRoomStorage();
        }
    } catch(e){
        console.warn('[ROOM] reset failed:', e);
    }

    /* ═══ ডেমো ইউজার + ডেমো রুম নিশ্চিত করা ═══ */
    if (typeof ensureDemoUsers === 'function'){
        try { ensureDemoUsers(); }
        catch(e){ console.warn('[DEMO] ensureDemoUsers failed:', e); }
    }
    if (typeof ensureDemoRooms === 'function'){
        try { ensureDemoRooms(); }
        catch(e){ console.warn('[DEMO] ensureDemoRooms failed:', e); }
    }

    /* ═══ Auto start — সরাসরি finishInit() ═══ */
    setTimeout(() => finishInit(), 60);
})();

/* ═══ Main init শেষ হলে ═══ */
function finishInit(){
    if (joined) return;

    initState();

    /* ═══ Auto role detect — নিজের রুম কিনা ═══ */
    if (state.owner && myProfile && state.owner.uid === myProfile.uid){
        state.myRole = 'owner';
        console.log('%c[ROLE] 👑 আপনি OWNER এই রুমে', 'color:#F5D76E;font-weight:bold');
    } else {
        state.myRole = 'member';
        console.log('%c[ROLE] 👤 আপনি USER/AUDIENCE এই রুমে', 'color:#00E5FF;font-weight:bold');
    }

    renderBranding();
    renderSeats();
    renderMessageFeed();
    renderListeners();
    renderMembers();
    renderTopGifters();
    joinRoom();
    buildEmojiCategories();
    renderEmojiGrid();

    initDragHandle('chatDragHandle', 'chatSheet');
    initDragHandle('gameDragHandle', 'gameSheet');

    startLuckyBoxTimer();

    /* ═══ Storage change listener (একই ব্রাউজারে অন্য ট্যাব) ═══ */
    window.addEventListener('storage', (e) => {
        if (e.key === KEY.seats){
            state.seats = ls_get(KEY.seats) || new Array(10).fill(null);
            renderSeats();
            updateMicButton();
        }
        if (e.key === KEY.listeners){
            state.listeners = ls_get(KEY.listeners) || [];
            renderListeners();
            renderMembers();
            $('userCountBadge').textContent = state.listeners.length;
            $('listenerTotalCount').textContent = state.listeners.length;
        }
        if (e.key === KEY.messages){
            state.messages = ls_get(KEY.messages) || [];
            renderMessageFeed();
        }
        if (e.key === KEY.giftStats){
            state.giftStats = ls_get(KEY.giftStats) || {};
            renderTopGifters();
        }
        if (e.key === KEY.wallpaper){
            const wp = ls_get(KEY.wallpaper);
            if (wp && wp.dataUrl) applyWallpaper(wp.dataUrl);
        }
        if (e.key === KEY.joined){
            state.joinedUsers = new Set(ls_get(KEY.joined, []) || []);
            updateJoinButton();
        }
    });

    /* ═══ Ring refresh ═══ */
    setTimeout(refreshAllRings, 100);
    setTimeout(refreshAllRings, 800);

    /* ═══ PK restore (আগে চালু থাকলে) ═══ */
    if (typeof pkRestoreFromStorage === 'function') pkRestoreFromStorage();

    console.log('[ROOM] ' + (state.myRole || 'member').toUpperCase() + ' — ' + state.roomName);
}

/* ═══ Drag handle (chat / game sheet) ═══ */
function initDragHandle(handleId, sheetId){
    const handle = $(handleId);
    const sheet = $(sheetId);
    if (!handle || !sheet) return;

    let dragging = false, startY = 0, startH = 0;

    const start = (e) => {
        dragging = true;
        startY = (e.touches ? e.touches[0].clientY : e.clientY);
        startH = sheet.offsetHeight;
        sheet.style.transition = 'none';
    };
    const move = (e) => {
        if (!dragging) return;
        const y = (e.touches ? e.touches[0].clientY : e.clientY);
        const dy = startY - y;
        let newH = startH + dy;
        const minH = window.innerHeight * 0.5;
        const maxH = window.innerHeight;
        newH = Math.max(minH, Math.min(maxH, newH));
        sheet.style.height = newH + 'px';
        sheet.style.maxHeight = newH + 'px';
    };
    const end = () => {
        if (!dragging) return;
        dragging = false;
        sheet.style.transition = '';
        const h = sheet.offsetHeight, maxH = window.innerHeight;
        sheet.style.height = '';
        sheet.style.maxHeight = '';
        if (h > maxH * 0.85) sheet.classList.add('fullscreen');
        else if (h < maxH * 0.6) sheet.classList.remove('fullscreen');
    };

    handle.addEventListener('touchstart', start, {passive:true});
    handle.addEventListener('touchmove', move, {passive:true});
    handle.addEventListener('touchend', end);
    handle.addEventListener('mousedown', start);
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', end);
}

/* ═══ Lucky Box inject hook ═══ */
(function hookMessageFeed(){
    const orig = window.renderMessageFeed;
    if (typeof orig === 'function'){
        window.renderMessageFeed = function(){
            orig.apply(this, arguments);
            injectLuckyBoxesIntoFeed();
        };
    }
})();

/* ═══ Global exports ═══ */
window.initDragHandle = initDragHandle;
window.finishInit = finishInit;