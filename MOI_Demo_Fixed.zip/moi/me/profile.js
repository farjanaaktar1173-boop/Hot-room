/* me/profile.js — নাম, ছবি বদলানো, Cropper */

console.log('[MOI] profile.js loaded');

const DEFAULT_AV = GUEST_AVATAR;
let cropper = null;

/* ═══ প্রোফাইল রেন্ডার ═══ */
function renderProfile(){
    document.getElementById('userName').textContent = window.me.name || 'User';
    document.getElementById('userUid').textContent = window.me.moiId || (window.me.uid ? window.me.uid.slice(0, 12) : '— — — — — —');
    const img = document.getElementById('profileImage');
    img.src = window.me.photo || DEFAULT_AV;
    img.onerror = () => { img.src = DEFAULT_AV; };
}

/* ═══ Follow সংখ্যা ═══ */
function loadFollowCounts(){
    const followers = ls_get('moi_follow_' + window.me.uid + '_followers', []) || [];
    const following = ls_get('moi_follow_' + window.me.uid + '_following', []) || [];
    document.getElementById('statFollowers').textContent = followers.length;
    document.getElementById('statFollowing').textContent = following.length;
}

/* ═══ Back button ═══ */
window.goBack = () => {
    if (history.length > 1) history.back();
    else location.href = URLS.home;
};

/* ═══ ছবি বদলানো (Cropper) ═══ */
function initCropper(){
    const imageInput = document.getElementById('imageInput');
    const cropModal = document.getElementById('cropModal');

    imageInput.addEventListener('change', (e) => {
        const files = e.target.files;
        if (!files || !files.length) return;
        const reader = new FileReader();
        reader.onload = (ev) => {
            document.getElementById('imageToCrop').src = ev.target.result;
            cropModal.classList.add('show');
            if (cropper){ cropper.destroy(); cropper = null; }
            setTimeout(() => {
                cropper = new Cropper(document.getElementById('imageToCrop'), {
                    aspectRatio:1, viewMode:1, autoCropArea:0.9,
                    background:false, guides:false, center:false, highlight:false
                });
            }, 120);
        };
        reader.readAsDataURL(files[0]);
    });

    document.getElementById('cropBtn').addEventListener('click', () => {
        if (!cropper) return;
        const canvas = cropper.getCroppedCanvas({ width:400, height:400, imageSmoothingQuality:'high' });
        const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
        window.me.photo = dataUrl;
        document.getElementById('profileImage').src = dataUrl;
        saveUser(window.me.uid, { photo: dataUrl });
        const cur = getCurrentUser();
        if (cur && cur.uid === window.me.uid){ cur.photo = dataUrl; setCurrentUser(cur); }
        toastMsg('প্রোফাইল ছবি আপডেট হয়েছে');
        window.closeCropModal();
    });
}

window.closeCropModal = () => {
    document.getElementById('cropModal').classList.remove('show');
    if (cropper){ cropper.destroy(); cropper = null; }
    document.getElementById('imageInput').value = '';
};

/* ═══ নাম বদলানো ═══ */
window.openNameModal = () => {
    if (!window.me.uid){ toastMsg('লগইন করুন','fa-lock'); return; }
    document.getElementById('newNameInput').value = window.me.name || '';
    document.getElementById('nameModal').classList.add('show');
    setTimeout(() => document.getElementById('newNameInput').focus(), 200);
};

window.closeNameModal = () => document.getElementById('nameModal').classList.remove('show');

function initNameChange(){
    document.getElementById('saveNameBtn').addEventListener('click', () => {
        const newName = document.getElementById('newNameInput').value.trim();
        if (!newName){ toastMsg('নাম খালি রাখা যাবে না','fa-triangle-exclamation'); return; }
        if (newName.length > 24){ toastMsg('সর্বোচ্চ ২৪ অক্ষর','fa-triangle-exclamation'); return; }
        window.me.name = newName;
        document.getElementById('userName').textContent = newName;
        saveUser(window.me.uid, { name: newName });
        const cur = getCurrentUser();
        if (cur && cur.uid === window.me.uid){ cur.name = newName; setCurrentUser(cur); }
        toastMsg('নাম আপডেট হয়েছে');
        window.closeNameModal();
    });
}

/* Follow লিস্ট → panels.js */

window.initCropper = initCropper;
window.initNameChange = initNameChange;
window.renderProfile = renderProfile;
window.loadFollowCounts = loadFollowCounts;